package tests;
import org.junit.Assert;
import org.junit.Test;
import vikingos.Vikingo;

public class TestMedita {

	public TestMedita() {
		// TODO Auto-generated constructor stub
		Vikingo v = new Vikingo(10,100);
	
		v.calmarse();
	}

}
