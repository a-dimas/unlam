package vikingos;

public enum EstadoActual {
	BERSERKER, NATURAL, MEDITACION;
}	